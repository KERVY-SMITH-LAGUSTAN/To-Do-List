# ToDoList_FRANCISCO
Simple To-Do List
Onion Architecture
